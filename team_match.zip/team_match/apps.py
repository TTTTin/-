from django.apps import AppConfig


class TeamMatchConfig(AppConfig):
    name = 'team_match'
